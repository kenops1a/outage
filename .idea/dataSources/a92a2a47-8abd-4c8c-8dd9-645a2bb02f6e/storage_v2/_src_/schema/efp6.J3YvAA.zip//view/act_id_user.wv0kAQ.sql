create view act_id_user as
select `u`.`user_name` AS `ID_`,
       0               AS `REV_`,
       `u`.`nick_name` AS `FIRST_`,
       ''              AS `LAST_`,
       `u`.`email`     AS `EMAIL_`,
       `u`.`password`  AS `PWD_`,
       ''              AS `PICTURE_ID_`
from `efp6`.`sys_user` `u`
where ((`u`.`del_flag` = '0') and (`u`.`status` = '0'));

