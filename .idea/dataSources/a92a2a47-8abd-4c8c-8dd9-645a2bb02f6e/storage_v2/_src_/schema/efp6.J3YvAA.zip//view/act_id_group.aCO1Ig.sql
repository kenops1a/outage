create view act_id_group as
select `r`.`id` AS `ID_`, NULL AS `REV_`, `r`.`role_name` AS `NAME_`, 'role' AS `TYPE_`
from `efp6`.`sys_role` `r`
where ((`r`.`del_flag` = '0') and (`r`.`status` = '0'))
union
select `efp6`.`sys_dept`.`id` AS `ID_`, NULL AS `REV_`, `efp6`.`sys_dept`.`dept_name` AS `NAME_`, 'dept' AS `TYPE_`
from `efp6`.`sys_dept`
where (`efp6`.`sys_dept`.`del_flag` = '0');

