create view act_id_membership as
select (select `u`.`user_name` from `efp6`.`sys_user` `u` where (`u`.`id` = `ur`.`user_id`)) AS `USER_ID_`,
       `ur`.`role_id`                                                                        AS `GROUP_ID_`
from `efp6`.`sys_user_role` `ur`
union
select (select `u`.`user_name` from `efp6`.`sys_user` `u` where (`u`.`id` = `up`.`user_id`)) AS `USER_ID_`,
       `up`.`dept_id`                                                                        AS `GROUP_ID_`
from `efp6`.`sys_user_dept` `up`;

